<table class="table">
    <thead class="thead-dark">
        <tr>
        <th scope="col">#</th>
        <th scope="col">Profile</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone</th>
        <th scope="col">Role</th>
        </tr>
    </thead>
    <tbody >
        <?php if(!$users->isEmpty()): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td><img src="<?php echo e(asset('storage/profile_image/'.$user->profile_image)); ?>" width="50px"></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->role->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="6">No Data Found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo $users->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/userdata.blade.php ENDPATH**/ ?>